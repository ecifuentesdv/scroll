window.env = {
//  API_URL: "https://apiorquestadormoneythor.niu.solutions/api/Integrador"
  //API_URL: "http://127.0.0.1:3030/api/Integrador"
  API_URL: "http://127.0.0.1:3030/api/Integrador"
};
