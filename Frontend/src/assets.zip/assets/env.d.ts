interface Window {
  env?: {
    API_URL?: string;
  };
}
